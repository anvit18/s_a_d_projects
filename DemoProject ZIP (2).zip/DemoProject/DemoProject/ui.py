import tkinter as tk
import subprocess

def run_script():
    subprocess.run(["python", "gen.py"])

# Create the main window
root = tk.Tk()
root.title("Run Script")

# Create a button to run the script
run_button = tk.Button(root, text="Run gen.py", command=run_script)
run_button.pack(pady=20)

# Run the Tkinter event loop
root.mainloop()
