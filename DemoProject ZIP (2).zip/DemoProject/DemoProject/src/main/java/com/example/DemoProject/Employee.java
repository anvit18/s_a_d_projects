package com.example.DemoProject.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    // Other columns
    private Integer EmployeeID;
    private String(50) EmployeeName;
    private Integer DepartmentID;

    // Getters and Setters
}
