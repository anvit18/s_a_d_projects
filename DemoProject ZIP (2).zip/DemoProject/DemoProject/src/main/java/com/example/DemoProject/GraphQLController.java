package com.example.DemoProject.graphql.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import graphql.schema.GraphQLSchema;
import graphql.GraphQL;

@RestController
@RequestMapping("/graphql")
public class GraphQLController {

    private final GraphQL graphQL;

    public GraphQLController(GraphQLSchema graphQLSchema) {
        this.graphQL = GraphQL.newGraphQL(graphQLSchema).build();
    }

    @RequestMapping(method = RequestMethod.POST)
    public Object executeGraphQL(String query) {
        return graphQL.execute(query).getData();
    }
}
