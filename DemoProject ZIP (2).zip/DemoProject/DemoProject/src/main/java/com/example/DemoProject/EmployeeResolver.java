package com.example.DemoProject.graphql.resolver;

import com.example.DemoProject.repository.EmployeeRepository;
import com.example.DemoProject.model.Employee;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.stereotype.Component;

@Component
public class EmployeeResolver {
    private final EmployeeRepository employeeRepository;

    public EmployeeResolver(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public DataFetcher<Employee> getEmployeeById() {
        return (DataFetchingEnvironment env) -> {
            Integer id = env.getArgument("id");
            return employeeRepository.findById(id).orElse(null);
        };
    }

    public DataFetcher<List<Employee>> getAllEmployees() {
        return (DataFetchingEnvironment env) -> employeeRepository.findAll();
    }
}
