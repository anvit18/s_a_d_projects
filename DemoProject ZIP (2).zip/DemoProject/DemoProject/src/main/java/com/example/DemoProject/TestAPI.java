package com.example.DemoProject;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/Test")
public class TestAPI {
    @GetMapping("/{api}")
    public String getTest(String TestID){
        return "Test Succesful";
    }
}
