package com.example.DemoProject.graphql.resolver;

import com.example.DemoProject.repository.DepartmentRepository;
import com.example.DemoProject.model.Department;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.stereotype.Component;

@Component
public class DepartmentResolver {
    private final DepartmentRepository departmentRepository;

    public DepartmentResolver(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    public DataFetcher<Department> getDepartmentById() {
        return (DataFetchingEnvironment env) -> {
            Integer id = env.getArgument("id");
            return departmentRepository.findById(id).orElse(null);
        };
    }

    public DataFetcher<List<Department>> getAllDepartments() {
        return (DataFetchingEnvironment env) -> departmentRepository.findAll();
    }
}
